module.exports = {
  BOT_TOKEN: "TOKEN LU", // Isi Token bot Telegram Ada, cek di @botFather
  OWNER_ID: "ID LU", // Isi ID Telegram Anda, cek di @MissRose_Bot
};